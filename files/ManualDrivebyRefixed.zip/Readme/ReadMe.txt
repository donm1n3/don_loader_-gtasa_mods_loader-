// Manual Driveby Refixed
// v.26.08.25

- This mod allows free aiming and shooting, as well as throwing grenades and using sprayable weapons, from inside any vehicle. 
- Based on MixMods version (03/07/22) of 'Manual Driveby Remake', but practically remade from scratch,
- fixing crashes, numerous bugs and adding new features.


---- REQUIREMENTS:

- Essentials Pack
  - https://www.mixmods.com.br/2019/06/sa-essentials-pack

- CLEO 4.4.4 or newer (already included in Essentials Pack), CLEO 5 recommended

- CLEO+ v1.2.0 or newer (a plugin for CLEO, already included in Essentials Pack)
  - https://www.mixmods.com.br/2023/10/cleoplus


---- INSTRUCTIONS:

- Delete any previous versions of "Manual Driveby Remake/ Refixed" completely.
- Place the folder "Manual Driveby Refixed" in your modloader directory   
- Open the file "DrivebySettings.ini" to customize everything to your liking

- If you want the old animations, replace the .ifp file with the one in the "optional" folder  
- For full vanilla animations, simply delete the .ifp file (not recommended, looks unrealistic)

- If you're using "Realistic Weapons Settings" mod then put the file "ManualDrivebyRefixed.cs" into the cleo folder of your game's root directory.

- If you're using "Advanced Aiming Mod", make sure you have set 'UPDATE_SETTINGS_PERMANENTLY 0' in aimingSets.dat 

- If you're using "Mixsets", set 'NoFixHandsToBars = 1' in Mixsets.ini to prevent a visual bug with stretched arms on bikes.

- I recommend using one of these mods that fix car animations because in vanilla the throwing animation looks buggy on bikes:
  - https://libertycity.net/files/gta-san-andreas/222557-animation-fix-new-car-anim-lcs-vcs.html
  - https://www.mixmods.com.br/2022/02/animation-fix-v1-5-corrigir-bugs-de-animacoes

- If aiming with your mouse doesn't work make sure that you have Silent Patch installed (included in Essentials Pack). Otherwise install this:
  - https://github.com/Bupropion78/mouse-fix

- Gamepad users: "ginput" recommended. If you use the controls layout 2, you must set driveby control type 5 or 6.

 
- For some extra fun, type the cheatcode 'MYNAMEISRAMBO' and see what happens and "MOMSREVENGE" if you want your homies to be like Rambo. ;)



---- FIXES FROM MANUAL DRIVEBY REMAKE:

- Fixed a possible crash, a camera zoom bug and visible crosshair when exiting vehicles
- Fixed crosshair getting larger after first shot
- Fixed automatic switching to submachine guns
- Fixed car moving while aiming and pressing 'E' or 'Q'
- Better gamepad support
- Fixed driveby shoot rate and missing reactions from NPCs
- Fixed an issue where nitro was triggered by shooting — now only the secondary fire button activates it  
- Fixed a conflict between bunnyhop and aiming on bicycles
- Fixed never falling off the bike while aiming


---- NEW FEATURES:

- Using throwable and sprayable weapons inside any vehicle (grenades, flamethrower etc)
- Using weapons in boats, helicopters, planes and trains
- Fully configurable key settings and mouse wheel support for weapon switching  
- Fully configurable shoot rate and availability for each weapon. Modders can use this to make any specific weapon selectable in vehicles  
- Recruiting gang members directly from within a vehicle, and provoking gang wars via driveby
- Aiming as a passenger
- Switching weapons during the missions "Just Business" and "End of the Line" 
- Option to automatically roll up car windows when exiting  
- Option to break the windshield when shooting forward  
- Keeps vanilla driveby available if you press the fire button before "look left/right"
- Option to disable manual driveby during missions  
- Option to exclude any vehicle from manual driveby  
- Enhanced camera options  
- Improved animations by ArtemQa146  
- Compatible with void’s "Modernized Driveby" mod  
- Compatible with the "Weapon Zoom Unlimited" mod
- Compatible with the "Easy Throw" mod


---- Known issue with First Person Mod v3.0/3.5:

- The camera turns backward when exiting aim mode in first-person view.  
- Some workaround options are included, but the issue must be fixed in the First Person Mod itself.
- Use "GFPSA" or "Ultimate First Person Mod". They are fully compatible.



---- Manual Driveby Authors:

- "Remake"
Original Author: ThirteenAG
Fixes and improvements: Junior_Djjr
Original .ifp Author: Zacthe_nerd

- "Refixed"
Author: CatchyKetchup
Improved .ifp Author: ArtemQa146
Contribution of memory addresses: vladvo

// Special Thanks to ArmanCan, H4D3S_HUEHUE, KaiQ, Kaoru Tanamachi, BrandonBaja, vladvo, ArtemQa146, K29, Bennymax, Cattuba, cemeteryblunts, Reaper
// ... and all other people that suggested ideas and reported bugs :)