Stories Sprinting by H-G

About:

Did you know that III, VC and SA all natively feature the ability to sprint with heavier weapons just like in LCS and VCS?
Well, for some reason, it seems R* kept this ability "disabled" until LCS and VCS by redirecting the heavy sprint animations to the heavy run ones.
Since Toni and Vic's movement animations are practically the BETA versions of CJ's movement animations, why not "restore" this native feature in SA and take the LCS animations for it?
Stories Sprinting brings you the most complete and proper port of the ability to sprint with all weapons from LCS and VCS to SA by using the most original and native approach ever!

Features:

- Fully native and direct implementation through the real R* methods. None of that scripted animation playing stuff!
- Compatible with the game's Super Sprint ability.
- The new sprinting animations tire CJ out appropriately, and don't work when tired.
- Sprinting with heavier weapons increases the player's Stamina stat naturally.

- Footstep sounds work correctly unlike all other mods.
- All-new, lore-friendly and proper fat and muscular variations for the new animations, meaning the mod also works when CJ is fat or muscular.
- Handgun run animation from LCS and VCS that works when CJ is wielding slightly larger one-handed weapons, also comes with proper fat/muscular variations.
- Optional .INI file with two compatibility options for other walkstyle-related mods.

- Optional ability to jump and sprint with the Minigun.
- Fixed the fat and muscular walkstyles having the idle stance animation set as the roadcross animation.
- The sprinting animations follow suit when a mission has player sprinting scripted to be disabled.
- Optional fix for the Fire Extinguisher that makes CJ use the Chainsaw/Flamethrower/Minigun walkstyle when holding it.

Installation:

Download and install Silent's ASI Loader: http://www.gtagarage.com/mods/show.php?id=21709
Extract "sprint.asi" and "sprint.txt" into your SA folder.

Download and install CLEO Library for SA: http://cleo.li
Extract "SA.StoriesSprinting.cs" and "SA.StoriesSprinting.ini" into your SA folder's "CLEO" folder.

Download and install Mod Loader: http://www.gtagarage.com/mods/show.php?id=25377
Create a new folder inside your SA folder's "modloader" folder, name it "Stories Sprinting" and extract the "Core" folder into it.

If your "ped.ifp", "fat.ifp" and/or "muscular.ifp" files are modified, download GTA Anim Manager: http://hotmist.ddo.jp/tool/animman/index.html
Extract the archive that contains GTA Anim Manager into a folder somewhere, extract "CustomPed.ifp", "CustomFat.ifp" and "CustomMuscular.ifp" somewhere too and run GTA Anim Manager.
Open your modified "ped.ifp", right-click "CustomPed.ifp", click "Open with Options...", click "OK" and save your changes.
Repeat the same process to add the animations from "CustomFat.ifp" and "CustomMuscular.ifp" to your modified "fat.ifp" and "muscular.ifp".

If you wish to be able to jump and sprint with the Minigun, go into the "Optional Extras" folder and extract the "Minigun Sprinting" folder into the "Stories Sprinting" folder.
If you use a mod that disables one of or both the fat and muscular walkstyles, like BeSlim, and/or don't want the Fire Extinguisher walkstyle fix, use "SA.StoriesSprinting.ini" to adjust the mod's options.

Credits:

All animations - SlingShot753
"eASIer" memory address patcher plugin (renamed to "sprint.asi" in this mod to avoid confusion) - HackMan128