  __  __ _      __  __           _
 |  \/  (_)    |  \/  |         | | 2022
 | \  / |___  _| \  / | ___   __| |___
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/


=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the folder "Collectibles on Radar" to your ModLoader folder.

-- Download the latest version of Essentials Pack: https://www.mixmods.com.br/2019/08/Essentials.html


 The mod will always show the not collected ones. To disable is F12 key (configurable by mod .ini file)
 The closest collectable will show even if it is far away.
 If no collectables appear, it's because there aren't any not collected yet, or it's incompatible with some hud/interface mod.

 In the .ini file of the mod you can also make the location of armour etc show by enabling with "true". Reactivating the mod while playing reloads the .ini.
 There you can also change the icon color by rgba hex color code (converted to signed integer).


Version: v1.1
--------------------

Author: kong78


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====
