// Example using gta3script with CLEO+
SCRIPT_START
{
    LVAR_INT pUrbanizeASI pExt_GetCharModel pExt_GetCharModelWithSeed pExt_GetVehicleModel pExt_GetVehicleModelWithSeed pExt_GetCharModelByStyleUsingIndex
    LVAR_INT pExt_GetVehicleModelByStyleUsingIndex pExt_GetObjectModel pExt_SetMessedPlace pExt_IsScriptInstalled pExt_IsScriptRunning pExt_AddExclusionZone
    LVAR_INT pExt_SetObjectModelChances pExt_ProcessObject pExt_GetObjectModelChances pExt_GetObjectModelByStyleUsingIndex
    LVAR_INT iResult pBuffer hObj i
    LVAR_FLOAT fResult
    
    WAIT 3000

    GET_LABEL_POINTER Buffer (pBuffer)

    IF GET_LOADED_LIBRARY "Urbanize (Junior_Djjr).asi" (pUrbanizeASI)

        //extern "C" int __declspec(dllexport) Ext_GetCharModel(int iStyle, int iStat, int iGenre)
        IF GET_DYNAMIC_LIBRARY_PROCEDURE "Ext_GetCharModel" pUrbanizeASI (pExt_GetCharModel)
            CALL_FUNCTION_RETURN pExt_GetCharModel 3 3 (/*iGenre*/ -1 /*iStat*/ -1 /*iStyle*/ 2)(iResult)
            PRINT_FORMATTED_NOW "Urbanize Test 'Ext_GetCharModel':~y~ %i" 5000 iResult
        ELSE
            PRINT_STRING_NOW "~r~Urbanize Test Error: Can't find 'Ext_GetCharModel'" 5000
        ENDIF
        WAIT 3000
        
        //extern "C" int __declspec(dllexport) Ext_GetCharModelWithSeed(int iStyle, int iStat, int iGenre, int iSeed)
        IF GET_DYNAMIC_LIBRARY_PROCEDURE "Ext_GetCharModelWithSeed" pUrbanizeASI (pExt_GetCharModelWithSeed)
            CALL_FUNCTION_RETURN pExt_GetCharModelWithSeed 4 4 (/*iSeed*/ 123456 /*iGenre*/ -1 /*iStat*/ -1 /*iStyle*/ 6)(iResult)
            PRINT_FORMATTED_NOW "Urbanize Test 'Ext_GetCharModelWithSeed':~y~ %i" 5000 iResult
        ELSE
            PRINT_STRING_NOW "~r~Urbanize Test Error: Can't find 'Ext_GetCharModelWithSeed'" 5000
        ENDIF
        WAIT 3000
        
        //extern "C" int __declspec(dllexport) Ext_GetVehicleModel(int iStyle, int iType)
        IF GET_DYNAMIC_LIBRARY_PROCEDURE "Ext_GetVehicleModel" pUrbanizeASI (pExt_GetVehicleModel)
            CALL_FUNCTION_RETURN pExt_GetVehicleModel 2 2 (/*iType*/ -1 /*iStyle*/ 5)(iResult)
            PRINT_FORMATTED_NOW "Urbanize Test 'Ext_GetVehicleModel':~y~ %i" 5000 iResult
        ELSE
            PRINT_STRING_NOW "~r~Urbanize Test Error: Can't find 'Ext_GetVehicleModel'" 5000
        ENDIF
        WAIT 3000
        
        //extern "C" int __declspec(dllexport) Ext_GetVehicleModelWithSeed(int iStyle, int iType, int iSeed)
        IF GET_DYNAMIC_LIBRARY_PROCEDURE "Ext_GetVehicleModelWithSeed" pUrbanizeASI (pExt_GetVehicleModelWithSeed)
            CALL_FUNCTION_RETURN pExt_GetVehicleModelWithSeed 3 3 (/*iSeed*/ 123456 /*iType*/ -1 /*iStyle*/ 5)(iResult)
            PRINT_FORMATTED_NOW "Urbanize Test 'Ext_GetVehicleModelWithSeed':~y~ %i" 5000 iResult
        ELSE
            PRINT_STRING_NOW "~r~Urbanize Test Error: Can't find 'Ext_GetVehicleModelWithSeed'" 5000
        ENDIF
        WAIT 3000
        
        //extern "C" int __declspec(dllexport) Ext_GetCharModelByStyleUsingIndex(int iStyle, int iIndex)
        IF GET_DYNAMIC_LIBRARY_PROCEDURE "Ext_GetCharModelByStyleUsingIndex" pUrbanizeASI (pExt_GetCharModelByStyleUsingIndex)
            CALL_FUNCTION_RETURN pExt_GetCharModelByStyleUsingIndex 2 2 (/*iIndex*/ 2 /*iStyle*/ 1)(iResult)
            PRINT_FORMATTED_NOW "Urbanize Test 'Ext_GetCharModelByStyleUsingIndex':~y~ %i" 5000 iResult
        ELSE
            PRINT_STRING_NOW "~r~Urbanize Test Error: Can't find 'Ext_GetCharModelByStyleUsingIndex'" 5000
        ENDIF
        WAIT 3000
        
        //extern "C" int __declspec(dllexport) Ext_GetVehicleModelByStyleUsingIndex(int iStyle, int iIndex)
        IF GET_DYNAMIC_LIBRARY_PROCEDURE "Ext_GetVehicleModelByStyleUsingIndex" pUrbanizeASI (pExt_GetVehicleModelByStyleUsingIndex)
            CALL_FUNCTION_RETURN pExt_GetVehicleModelByStyleUsingIndex 2 2 (/*iIndex*/ 3 /*iStyle*/ 5)(iResult)
            PRINT_FORMATTED_NOW "Urbanize Test 'Ext_GetVehicleModelByStyleUsingIndex':~y~ %i" 5000 iResult
        ELSE
            PRINT_STRING_NOW "~r~Urbanize Test Error: Can't find 'Ext_GetVehicleModelByStyleUsingIndex'" 5000
        ENDIF
        WAIT 3000
        
        //extern "C" int __declspec(dllexport) Ext_GetObjectModel(int iStyle)
        IF GET_DYNAMIC_LIBRARY_PROCEDURE "Ext_GetObjectModel" pUrbanizeASI (pExt_GetObjectModel)
            CALL_FUNCTION_RETURN pExt_GetObjectModel 1 1 (/*iStyle*/ 0)(iResult)
            PRINT_FORMATTED_NOW "Urbanize Test 'Ext_GetObjectModel':~y~ %i" 5000 iResult
        ELSE
            PRINT_STRING_NOW "~r~Urbanize Test Error: Can't find 'Ext_GetObjectModel'" 5000
        ENDIF
        WAIT 3000
        
        //extern "C" void __declspec(dllexport) Ext_SetMessedPlace(float x, float y, float z)
        IF GET_DYNAMIC_LIBRARY_PROCEDURE "Ext_SetMessedPlace" pUrbanizeASI (pExt_SetMessedPlace)
            CALL_FUNCTION pExt_SetMessedPlace 3 3 (/*zyx*/ 10.0 1000.0 1000.0)()
            PRINT_FORMATTED_NOW "Urbanize Test 'Ext_SetMessedPlace':~y~ (called)" 5000
        ELSE
            PRINT_STRING_NOW "~r~Urbanize Test Error: Can't find 'Ext_SetMessedPlace'" 5000
        ENDIF
        WAIT 3000
        
        //extern "C" int __declspec(dllexport) Ext_IsScriptInstalled(char* name)
        IF GET_DYNAMIC_LIBRARY_PROCEDURE "Ext_IsScriptInstalled" pUrbanizeASI (pExt_IsScriptInstalled)
            COPY_STRING "SA\GUARD.cs" ($pBuffer) //as shown in ShowDebug (include location folder, except for non-location scripts)
            CALL_FUNCTION_RETURN pExt_IsScriptInstalled 1 1 (/*name*/ pBuffer)(iResult)
            PRINT_FORMATTED_NOW "Urbanize Test 'Ext_IsScriptInstalled':~y~ Name '%s' result is %i" 5000 $pBuffer iResult
        ELSE
            PRINT_STRING_NOW "~r~Urbanize Test Error: Can't find 'Ext_IsScriptInstalled'" 5000
        ENDIF
        WAIT 3000
        
        //extern "C" int __declspec(dllexport) Ext_IsScriptRunning(char* name)
        IF GET_DYNAMIC_LIBRARY_PROCEDURE "Ext_IsScriptRunning" pUrbanizeASI (pExt_IsScriptRunning)
            COPY_STRING "SA\GUARD.cs" ($pBuffer) //as shown in ShowDebug (include location folder, except for non-location scripts)
            CALL_FUNCTION_RETURN pExt_IsScriptRunning 1 1 (/*name*/ pBuffer)(iResult)
            PRINT_FORMATTED_NOW "Urbanize Test 'Ext_IsScriptRunning':~y~ Name '%s' result is %i" 5000 $pBuffer iResult
        ELSE
            PRINT_STRING_NOW "~r~Urbanize Test Error: Can't find 'Ext_IsScriptRunning'" 5000
        ENDIF
        WAIT 3000
        
        //extern "C" void __declspec(dllexport) Ext_AddExclusionZone(float x, float y, float z, float fRadius, int iMode)
        IF GET_DYNAMIC_LIBRARY_PROCEDURE "Ext_AddExclusionZone" pUrbanizeASI (pExt_AddExclusionZone)
            CALL_FUNCTION pExt_AddExclusionZone 3 3 (/*iMode*/ 0 /*fRadius*/ 100.0 /*zyx*/ 10.0 1000.0 1000.0)() //just like .dat file
            PRINT_FORMATTED_NOW "Urbanize Test 'Ext_AddExclusionZone':~y~ (called)" 5000
        ELSE
            PRINT_STRING_NOW "~r~Urbanize Test Error: Can't find 'Ext_AddExclusionZone'" 5000
        ENDIF
        WAIT 3000

        //extern "C" int __declspec(dllexport) Ext_GetObjectModelChances(int modelIndex)
        IF GET_DYNAMIC_LIBRARY_PROCEDURE "Ext_GetObjectModelChances" pUrbanizeASI (pExt_GetObjectModelChances)
            CALL_FUNCTION_RETURN pExt_GetObjectModelChances 1 1 (/*modelid*/1255)(iResult)
            PRINT_FORMATTED_NOW "Urbanize Test 'Ext_GetObjectModelChances':~y~ result is %i" 5000 iResult
        ELSE
            PRINT_STRING_NOW "~r~Urbanize Test Error: Can't find 'Ext_GetObjectModelChances'" 5000
        ENDIF
        WAIT 3000

        //extern "C" void __declspec(dllexport) Ext_SetObjectModelChances(int modelIndex, int chances)
        IF GET_DYNAMIC_LIBRARY_PROCEDURE "Ext_SetObjectModelChances" pUrbanizeASI (pExt_SetObjectModelChances)
            CALL_FUNCTION pExt_SetObjectModelChances 2 2 (/*percent*/100 /*modelid*/1255)()
            PRINT_FORMATTED_NOW "Urbanize Test 'Ext_SetObjectModelChances':~y~ (called)" 5000
        ELSE
            PRINT_STRING_NOW "~r~Urbanize Test Error: Can't find 'Ext_SetObjectModelChances'" 5000
        ENDIF
        WAIT 3000

        //extern "C" int __declspec(dllexport) Ext_ProcessObject(CObject *obj)
        IF GET_DYNAMIC_LIBRARY_PROCEDURE "Ext_ProcessObject" pUrbanizeASI (pExt_ProcessObject)
            CREATE_OBJECT_NO_SAVE 1255 0.0 0.0 10.0 FALSE TRUE (hObj)
            GET_OBJECT_POINTER hObj (i)
            CALL_FUNCTION pExt_ProcessObject 1 1 (/*cobject*/i)()
            PRINT_FORMATTED_NOW "Urbanize Test 'Ext_ProcessObject':~y~ (called)" 5000
            DELETE_OBJECT hObj
        ELSE
            PRINT_STRING_NOW "~r~Urbanize Test Error: Can't find 'Ext_ProcessObject'" 5000
        ENDIF
        WAIT 3000

        //extern "C" int __declspec(dllexport) Ext_GetObjectModelByStyleUsingIndex(int iStyle, int iIndex)
        IF GET_DYNAMIC_LIBRARY_PROCEDURE "Ext_GetObjectModelByStyleUsingIndex" pUrbanizeASI (pExt_GetObjectModelByStyleUsingIndex)
            CALL_FUNCTION_RETURN pExt_GetObjectModelByStyleUsingIndex 2 2 (/*index*/0 /*stle*/2)(iResult)
            PRINT_FORMATTED_NOW "Urbanize Test 'Ext_GetObjectModelByStyleUsingIndex':~y~ result is %i" 5000 iResult
        ELSE
            PRINT_STRING_NOW "~r~Urbanize Test Error: Can't find 'Ext_GetObjectModelByStyleUsingIndex'" 5000
        ENDIF
        WAIT 3000

    ELSE
        PRINT_STRING_NOW "~r~Urbanize Test Error: 'Urbanize (Junior_Djjr).asi' not installed." 5000
    ENDIF
}
SCRIPT_END

Buffer:
DUMP
00 00 00 00 00 00 00 00 //8
00 00 00 00 00 00 00 00 //16
00 00 00 00 00 00 00 00
00 00 00 00 00 00 00 00 //32
ENDDUMP
