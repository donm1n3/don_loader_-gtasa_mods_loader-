  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2025
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced font, as "Consolas".


------- Instructions:

Exctract the folder "Project2DFX" to your Modloader folder.

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html


This mod already comes with Open Limit Adjuster:
https://www.mixmods.com.br/2022/10/open-limit-adjuster/
Remembering that Open Limit Adjuster is incompatible with SOME FEW settings of fastman92 limit adjuster.


== Notes ==
 You can open the file "SALodLights.ini" to configure with you taste. - TUTORIAL: MixMods.com.br/2016/03/tutorial-como-configurar-o-project2dfx.html

 In the "(settings)" folder there are some settings options. Use "low" if your PC is weak.

 If you don't have that light effects on lampposts, disable "RenderSearchlightEffects"! (put "0")

 If you use LOD Vegetation or Proper Fixes, you don't need to increase the distance to the trees, so you can remove or leave 0.0 or 1.0 in the "VegetationDrawDistance" line.

 If objects flickering, open "III.VC.SA.LimitAdjuster.ini" and increase "MemoryAvailable". (or "StreamMemory" from MixSets or use Improved Streaming mod)

 If you have problems with the lights, make sure you are using version 2025+ of Widescreen Fix: https://www.mixmods.com.br/2021/05/widescreen-fix-para-gta-sa-corrigir-widescreen/



Version: v4.4 + 2024 Update + FestiveLights = 0; LoadAllBinaryIPLs = 0; not forced generic distance.
--------------------

Author: ThirteenAG, TJGM
Credits: Silent, _DK, Wesser, fastman92, LINK/2012, maxorator;


====   MixMods.com.br         ====
====   fb.com/FamiliaMixMods  ====

