---
EN-
---

Pickups Mod

With this mod, you can make your pickups look like pickups from GTA 4 (lying on the ground), GTA VC or GTA 3 (glow). Well, or even do as your heart desires.
There are two modes available:
1. Pickups on the ground (as in GTA 4);
2. Classic pickups (visual effects only).
The modes are switched in the .ini file. You can also customize the following settings for yourself:
- The light from the pickup truck on the ground. You can change the size and transparency. (The color is only for weapons);
- The size of the pickup model itself. The game has quite large pickup models from save, wanted star, health, etc., you can adjust the size of any;
- You can enable the display of the number of bullets or the amount of money above the pickup. Additionally customize the font, text color (Black or white);
- You can adjust the light from the model itself (corona). Size, Transparency, type, glare effect;
- For the "Pickups on Earth" mode, you can additionally adjust the rotation speed of the save pickups, stars, and so on. Or just stop the rotation.

v1.1
- For the "Pickups on the ground" mode, an option has been added in .ini so that only pickups with weapons and money that have fallen out after death lie on the ground.

It works in SAMP and is compatible with the Glowing Pickups mod. (Tested by eCoJ)
There are several types of different settings inside the archive.

-----------------------------------------------------------------
Installation:
Move the "Pickups Mod" folder to the "Modloader" folder. Ready!
-----------------------------------------------------------------
by ArtemQa146

https://www.gtainside.com/user/ArtemQa146
https://libertycity.ru/user/Artem.1.9.9.6/
https://youtube.com/@ArtemQa146