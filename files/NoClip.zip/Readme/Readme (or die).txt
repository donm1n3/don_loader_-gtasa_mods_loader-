  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2022
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Exctract the folder "NoClip" to your Modloader folder.

-- Essentials Pack download: https://www.mixmods.com.br/2019/06/sa-essentials-pack/
-- REQUIRES CLEO+ (already included in Essentials Pack).



 = Commands:
Type "NOC" to enable/disable (configurable in the "No Clip.ini" file)
W and S to go forward and backward (toward the camera).
Q and E to go up and down.
Mouse wheel to adjust the speed.

To remove the informations on the screen, disable (0) "ShowInfos" in the .ini file
 


Version: v1.2
--------------------

Author: Junior_Djjr


====   MixMods.com.br         ====
====   fb.com/FamiliaMixMods  ====

