  __  __ _      __  __           _
 |  \/  (_)    |  \/  |         | | 2025
 | \  / |___  _| \  / | ___   __| |___
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/


=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the folder "GPS Redux" to your ModLoader folder.

-- Essentials Pack download: https://www.mixmods.com.br/2019/06/sa-essentials-pack/


 Simply mark a destination on the map in the pause menu and the line will appear when driving a car.
 Also shows for mission objectives.

 In the .ini file there are more cosmetic and functional options.
 If you want the GPS to respect the traffic laws, put "true" in "respectTrafficLaneDirection".

 For SAMP, download the old version in MixMods.


Version: v1.5
--------------------

Author: juicermv
Previous improvements: Junior_Djjr
Original mod: DK22Pac


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====
