  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2026
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization in Notepad with monospaced font, as "Consolas".


------- Instructions:

Extract the folder "VehFuncs" to your Modloader folder.

-- Download of Essentials Pack: https://www.mixmods.com.br/2019/06/sa-essentials-pack/



ATTENTION: The mod includes "gsx.asi", make sure that you don't already have it installed by another mod that also uses it.
           Now the mod already includes "IndieVehicles.asi" integrated inside it if you don't have it installed. Now IndieVehicles is deprecated and mods and players should use VehFuncs instead.
           A few features requires Soundize to have effect: https://www.mixmods.com.br/2025/08/soundize/

Learn how to adapt a vehicle here: https://github.com/JuniorDjjr/VehFuncs/wiki


There's a basic logging sytem. You can find infos, errors etc in file "VehFuncs.log" at mod asi folder.
The mod also detect and shows informations about some common vehicle crash errors.
It's written when closing or defocus (e.g. minimize) the game.

If you are adapting or testing cars in the game, it is recommended to enable "Log = 1" in "VehFuncs.ini".



Version: v2.5.3
--------------------

Author: Junior_Djjr
Mod GSX and helps: Fabio
Thanks to: DK22Pac, _F_, Avant, M4k3, xXKenBlockXx, dxivilea, recoil, Zeneric
Special thanks to plugin-sdk contributors


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====

