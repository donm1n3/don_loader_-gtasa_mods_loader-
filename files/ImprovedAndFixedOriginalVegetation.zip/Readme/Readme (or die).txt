  __  __ _      __  __           _
 |  \/  (_)    |  \/  |         | | 2021
 | \  / |___  _| \  / | ___   __| |___
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/


=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the folder "Improved and Fixed Original Vegetation" to your Modloader folder.

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html


 If you have other mods that replace trees, adjust the priority of this mod's folder in modloader.ini:
 https://www.mixmods.com.br/2015/07/tutorial-dicas-tudo-sobre-mod-loader.html#Priority
 Remembering that some mods that fixes prelighting also replace trees,
 therefore priority is recommended above it, but below other HD trees.
 This mod does NOT replace textures.


Version: 08/03/21 (DD/MM/YY) - Unofficial sjmpalmtall fix
--------------------

Author: decipher96


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====
