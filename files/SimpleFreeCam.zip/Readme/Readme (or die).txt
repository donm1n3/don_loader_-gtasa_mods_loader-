  __  __ _      __  __           _
 |  \/  (_)    |  \/  |         | | 2022
 | \  / |___  _| \  / | ___   __| |___
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/


=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the "Simple Free Cam" folder into the ModLoader folder.

-- Essentials Pack download: https://www.mixmods.com.br/2019/06/sa-essentials-pack/
-- Requires CLEO+ (included in download above)


 = Commands:
CONFIGURABLE IN MOD .INI FILE!
 K+M turns on/off.
 I and K move back and forth.
 Moving the mouse rotates the camera.
 Mouse wheel or 9 and 0 changes speed. SHIFT for faster.
 Enter teleports CJ to camera position.
 "Insert" teleports CJ to the camera position. Hold "SHIFT" to use the ground position.
 "Home" saves the position and camera in the .ini file, useful for using the value in mods etc.

In the mod's .ini file, in addition to the commands, you can disable information on the screen, or hide the hud.


Version: v2.1.1
--------------------

Author: Junior_Djjr


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====
