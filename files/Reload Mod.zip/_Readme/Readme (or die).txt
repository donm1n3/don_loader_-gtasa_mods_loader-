  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2025
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the folder "Reload Mod" to your Modloader folder.
Remove "Reload Mod (Junior_Djjr).cs" if you have old version installed.

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html



 = Commands:
By default, R on keyboard.
If coop with player 2: down arrow on pad 2.
You can change the commands in the mod .ini file.

In the .ini you can also choose whether to reload even if the clip is full.

For manual reload when the clip is empty, you need KeepNoAmmo mod:
https://www.mixmods.com.br/2020/03/keep-no-ammo.html
(there is a option for this in .ini)
 


Version: v1.3
--------------------

Author: Junior_Djjr
Improvements: GillianMC


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====

