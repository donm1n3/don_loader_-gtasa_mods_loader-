  __  __ _      __  __           _
 |  \/  (_)    |  \/  |         | | 2024
 | \  / |___  _| \  / | ___   __| |___
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/


=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the folder "2 Player Deluxe" to your ModLoader folder.

-- Essentials Pack download: https://www.mixmods.com.br/2019/06/sa-essentials-pack/
-- REQUIRES CLEO+ (already included in Essentials Pack).
-- REQUIRES GInput: https://www.mixmods.com.br/2021/01/iii-vc-sa-ginput-melhor-suporte-para-controles/

 For Splitscreen: https://forum.mixmods.com.br/f5-scripts-codigos/t8670-sa-split-screen-for-2-player-mode-v1-2

 Tip: Leave this file in the mod folder, for later reference in case of doubts or problems.
      If you play the story mode, frequently save your saved game.
      More info: https://forum.mixmods.com.br/f5-scripts-codigos/t7571-sa-2-player-deluxe


== ATTENTION:
This mod uses global variables, so it can corrupt your save game and cause conflicts with other mods that also use it.
Do not use this mod in your main saved game!!!



== How to play in 2:
Use a gamepad controller working on your PC supporting XInput (otherwise you will have to use x360ce or XOutput).
To play on the keyboard and the second player on the controller, just put "MapPadOneToPadTwo=1" in the GInput's "GInputSA.ini" file.
You can use SAAC to play both on the same keyboard but it's not recommended.



== Controls:
The mod is set to always start on 2 players.
You can set it in "config_mod.ini" to "always_coop=0", so you need to press START on the second pad.

Player 1 (with controller)
    L1 + Right to open the options/cheat menu.

Player 1 (with keyboard)
    Answer call or secondary shot + Positive answer to open the options/cheat menu.

Player 2
    L1 + Right to open skin selector
    L1 + Left to teleport next to player 1
    START/PAUSE to spawn/despawn (if you have "Always coop" disabled).
    L1 + R3 to attach to player 1's vehicle.
    While in turret mode, left and right to rotate.

Both players
- Press the horn button to force the mission character to get in.



== BUGS:

- (NOT IMPORTANT) If both players touch each other while parachuting, it is possible for one player to die. 
- (IMPORTANT) In rare cases player 2 will be controlled by the computer. In these cases just use teleportation to return to normal (L1 + Left).
- (IMPORTANT) If player 2 dies while the first player is falling with a parachute, then he will no longer be able to switch weapons and it will be necessary to restart the game.
- (VERY IMPORTANT) Dying during a transition, either mission or kill/arrest can cause the mod to stop working completely. If you appear in the center of the map, then restart the game. 

Any other bugs caused by player 2 not being there (such as getting into a vehicle in a garage when it is closing) or ruining a cinematic is not a problem of the mod.



Version: v1.5
--------------------

Main Credits: 
Kaizo M: Original idea, author of Project Kaizo for PS2, PS3, X360, XBOX and Android, fix weapons with special camera in 2 player mode, validations in missions, 2 player icons and translation to Spanish, Portuguese and English.

ArTuRMV, Daniel Santos: Original turret mode idea, skin selector with custom skins for player 2 and remove 2 player mode restrictions (Enable ENEX markers, red circles and garages).

Secondary credits: 
- Skatefilter5 for being the first to make a coop anywhere in 2017.
- Diogo Santos (BS) for extracting the unnecessary from the PTMG cheat menu.
- ZAZ for basic SCM tutorials.
- Nadalao for scripts referenced in his Recruit 2 Player mod for PC (Get in the same vehicle, give weapons and create player with CLEO+).
- Junior_Djjr for CLEO+


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====
