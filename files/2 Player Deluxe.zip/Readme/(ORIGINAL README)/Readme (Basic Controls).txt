******************************************
********** 2 Player Deluxe  **************
********** by Kaizo M	******************
******************************************

Enable a coop game always, anywhere, in any GTA SA.

Current version: 1.5 Probably the last one!! Enjoy it!

Important note: As of version 1.3 the mod no longer includes any cheat menu, nor does it create global variables so it is more stable than before and especially easier to use. No complex options

Before you play it, you need:
- Modloader
- CLEO 4.4
- CLEO+
- GInput (play with controllers)
- In case that your controllers are generic or doesn't support XInput, you need x360ce.

Here are the links: 

Modloader
https://www.gtagarage.com/mods/show.php?id=25377

Cleo 4.4. YOU ESPECIALLY NEED CLEO+
https://www.mixmods.com.br/2020/10/biblioteca-cleo-4-4/

GInput
https://www.mixmods.com.br/2021/01/iii-vc-sa-ginput-melhor-suporte-para-controles/

***********
INSTALATION
***********

Drag "2 Player Deluxe" folder into modloader. Check the readme inside "custom_skins" 


***********
CONTROLS / ACTIVATIONS
***********
Player 1 
    L1 + Right to open skin selector (TAB + Y on foot) v.1.3
    L1 + Left to open options/settings menu (TAB + N on foot) v.1.3

Player 2
        L1 + Right to open skin selector.
        L1 + Left to teleport next to first player.
        START/PAUSE to spawn/despawn (if you have "Always coop" disabled).
        L1 + R3 to attach to player 1's vehicle.
        While in turret mode, left and right to rotate.

Both players
    Press the horn button to force the mission character to get on.
    Down and right click  the joystick  Press R3 to change camera zoom (Middle Mouse Button) v.1.3    
    While drive-by, hold the aim-button to focus on a target.  v.1.3


************************
CREDTIS
************************

Main Credits: 
Kaizo M: Original idea, author of "coop anywhere" for PS2, PS3, XBOX and Android, fix weapons with special camera in 2 player mode, validations in missions, 2 player icons and translation to Spanish and English.

ArTuRMV and Daniel Santos: Original turret mode idea, skin selector with custom skins for player 2 and remove 2 player mode restrictions (Enable ENEX markers, red circles and garages).

Secondary credits: 
- Skatefilter5 for being the first to make a coop anywhere in 2017.
- Diogo Santos (BS) for extracting the unnecessary from the PTMG cheat menu.
- ZAZ for basic SCM tutorials.
- Nadalao for scripts referenced in his Recruit 2 Player mod for PC (Get in the same vehicle, give weapons and create player with CLEO+).
- Junior_Djjr for CLEO+
- Silent and Deji for GInput