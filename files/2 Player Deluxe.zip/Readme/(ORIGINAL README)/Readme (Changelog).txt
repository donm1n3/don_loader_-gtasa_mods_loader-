V1.5  
January 20th, 2024
Added.

    Added "splitscreen_enhacements" option in-game mod menu because I forgot to add it in version 1.4
    Added "Icon Adjustment" in menu and in .ini file. It's enable when splitscreen_enhacements is on. Select if you're playing with vertical or horizontal orientation for adjust the 1P and 2P icon aspect ratio.


Fixed

    Player 2 will no longer honk a horn from a lowrider vehicle. 
    "Blood Ring" stadium work as before. No crashes anymore.

Changed

    If player one is using a jetpack, player two will be given a jetpack when he teleports with him (Useful for Black Project mission). But if player two is already using a jetpack, teleport will no work to make both players messing around in air.

	

V1.4 
October 17th, 2023
Fixed

    Small fixes related to player 2's lung capacity, icons and the 'coop anywhere' option (always_coop = 0)
    Skin selector is now disabled when driving.

Changed

    When the camera focuses on a player, the icon above will not appear.

Added.

    Player 2 can now honk a vehicle horn.
    Player 2 can now replace any weapon of the same type. This bug comes from Rockstar.
    If player 2 has a weapon with special camera (like sniper, photo camera, rocket launcher, etc) it will be removed from the inventory.
    Player 2 can detach from a vehicle by pressing Triangle/Y (L3 + L1 is still an option)
    A new option was added in 2P_config.ini called "splitscreen_enhacements¨. If you have the splitscreen mod, YOU MUST enable this option to slightly improve the experience. It includes these features:
        Improves the separation distance. From 100mts to 185mts
        Automatic teleportation will be disabled if both players are in separate vehicles.
        "1P" and "2P" icons are respectively displayed only on the other player's screen, and disappear if the players are close to each other.

 Other

    Added a readme inside "custom_skins" folder explaining how to install custom skins and use the menu.

//************************************************************************************************************
//************************************************************************************************************
//************************************************************************************************************
//************************************************************************************************************
V1.3 
August 15th, 2023
Fixed

    This mod no longer creates any global variables to work.
    Fixed losing focus when aiming a weapon while moving the camera.
    Player two's lung capacity is working properly. Now he is capable of drowning.
    Fixed crash when loading another save file.
    Fixed bugs with invisible weapons or infinite ammo that could occur while playing story missions.
    Fixed bugged textures when playing dance minigame.

 Changed

    Zooming in/out camera (as in singleplayer) is now done by pressing R3/RS (on PC it's the mouse wheel)
    Every time a change is made in options menu it'is necessary to restart the mod.
    "Rampage auto-aim" on specific missions will no longer appear as it is now a feature of the mod.
    To activate the options menu, player 1 must press L1 + Left (TAB + N on foot) and pressing L1 + Right (TAB + Y on foot) will open his skin selector, just like player 2.
    Slight changes in text strings.

 Added

    Player two can now change radio stations while he is driving.
    Pressing the aim button during a drive-by will show auto-aim for massacre missions. By default it aims at pedestrians, pressing SELECT/BACK will switch to vehicles (due to PC version bug, auto-aim doesn't follow target, you'll have to keep doing it manually). Includes a configurable icon in the ini file.

 Removed

    Removed kissing feature.
    Removed independent weapons feature
    Removed player two independent weapons feature per save file.
    Removed giving weapons between players.
    Removed hot coffee skins in skin selector.

 Files and installation

    Removed unnecessary cheat menu. The menu now only has necessary options like skin selector and options for the mod.
    Removed language file (fxt) now the texts are included inside the cleo script.
    Removed cleo script 2pl_drvb_ctrl. Isn't stable for story missions, and also that cleo script was not made by me.
    Removed peds.ide file. It may cause problems if you have mods that add or change peds. If you want player 2 to run as CJ, then modify it yourself.

 Other

    Better use of CLEO+ opcodes
    Redesign of player indicators (Only in game, I'm lazy to change the logo).
    Improved the texture of crosshair when doing drive-by. It is lore-friendly since the original texture comes from Vice City with a resolution of 256x256 pixels while in San Andreas it is 64x64 pixels.
//************************************************************************************************************
//************************************************************************************************************
//************************************************************************************************************
//************************************************************************************************************
V1.1
March 21th, 2022

    Player 2 can now kill all characters that were strictly coded only for CJ to kill them (by Junior_Djjr).
    Renamed the configuration file. You can renamed your previous save file in case that you already have config your mod.
    Improved the format of the icons that identify players.
    Removed the "Create actor" option from the skin selector. 
    Player 2 will not be left with 0.0 ammo when attached to player 1's vehicle.
    Small improvements in scripts
        Fixed player 2 changing from SPECIAL9 to SPECIAL1 when using the skin selector.
        Reduced amount of global variables created by the mod.
    Added "Extra" folder, contains useful but optional mods to play. 
        Peds.ide, special actors controlled by player 2 will be able to run as CJ.
        2pl_drvb_ctrl, players will be able to enable/disable drive-by when sharing vehicle (original by Marsi4eg).
//************************************************************************************************************
//************************************************************************************************************
//************************************************************************************************************
//************************************************************************************************************
V1.1.1
March 29th, 202

    Improved translation from Portuguese (by VINICIAAO)
    Fixed fatal crash when using a vehicle
//************************************************************************************************************
//************************************************************************************************************
//************************************************************************************************************
//************************************************************************************************************
V1.2
April 24th, 2022

    Fixed potential softlock when using the optional 2pl_drvb_ctrl mod. 
    Player icons slightly have a larger size and have a behavior closer to The Warriors (Fades if a player is inactive).
    Adjustments in the following missions:
        Wrong Side of the Tracks.
            Big Smoke will wait at home while players kills Los Vagos.
            Fixed players ending up with infinite ammo when finishing the mission.
        OG LOG
            Jeffrey will wait at the Burger Shot while players kills Freddy. 
            During the chase, the automatic aim on Freddy's vehicle will be activated.
    Slight changes in the mod menu (Unnecessary options have been removed from the cheat menu).
    Fixed crash when selecting CSDRESS from the skin selector. 
    Separately you can download new textures for player icons.

//************************************************************************************************************
//************************************************************************************************************
//************************************************************************************************************
//************************************************************************************************************

V1.0
March 11th, 2022

    Official release.
