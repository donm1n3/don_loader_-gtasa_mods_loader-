Authors:Authors:Razor1096, Alvian9xpro,Artem,and Cattuba (me)

Weapon Change Anim Fixed is:
the original mod + Artem's edit to make it work better with his mods and my edit to disable it in cutscenes to avoid softlock on a mission like house party where cj does the weapon change anim and doesn't move in the very last cutscene

Installation:
Copy "Weapon Change Anim Fixed" folder to your modloader folder

Update 1.1:
MOSTLY fixed losing control of the player if he's on fire and you're trying to switch weapons
there is still a small chance of this happening so pls if u can help me improve this dm me

Update 1.2:
Fixed instability of previous update sorry about that

update 1.3:
fixed softlock in "a Home in the Hills" mission if the player started it with a weapon in hand
Added a new animation for crouching if the player has stopped
