  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2021
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the folder "Green Piece" to your Modloader folder.

To have the trees seen from distance, with LOD (minimum FPS impact), use the LOD Vegetation Mod
https://www.mixmods.com.br/2021/08/lod-vegetation-arvores-distantes.html
E instale este mod pela pasta "(alt - LOD Vegetation)".

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html
 

Version: v1.37 Unofficial Fix + LOD Vegetation
--------------------

Author: CR_crash
Fixes: Junior_Djjr


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====

