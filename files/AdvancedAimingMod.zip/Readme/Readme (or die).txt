  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2020
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the folder "Advanced Aiming Mod" to your Modloader folder.

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html


 You can open the .dat file with notepad to configure the mod.
 In offsets, each weapon is configured by the ID number (adapted for added weapons):
 https://wiki.sa-mp.com/wiki/Weapons
 "UPDATE_SETTINGS_PERMANENTLY 1" allows you to configure without closing the game, return "0" after finishing.
 The .dat file is delicate, careful when removing or adding default lines.

 Command: Z and X keys to change sides. Or the command to look back (R3 or middle mouse button).

 In "VIRTUAL_KEY" and "BUTTON" you choose the keys (virtual key) or commands for the game.
 https://www.mixmods.com.br/p/virtual-keys-br.html
 https://gtagmodding.com/sanandreas/pads/
 You can use equal numbers (for example, "90 90") to use the same key for both sides.
 Also, "0 0" to disable for example the keys or buttons.


Version: v1.4
--------------------

Author: DK22Pac
Added weapons support: Junior_Djjr


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====

