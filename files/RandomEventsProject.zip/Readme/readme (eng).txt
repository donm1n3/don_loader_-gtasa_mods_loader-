---
EN-
---

Random Events Project

The mod adds various random GTA V and RDR2 style events throughout the state of San Anrdeas. Most events have at least 2 possible outcomes, in some even more, it all depends only on the actions of the main character (or his inaction). Also, many have small cut scenes, voice acting (directly from GTA V) and various awards that you can get immediately or after a while or not at all. When you are close to the place of the event, a "Question" sign will appear on the map. The archive has a map with the exact location and description of all events, BUT I strongly recommend installing the mod and just playing and going about your business without knowing their location and other details, that's exactly what was intended, that's how it will be interesting! In the Settings.ini file, you can select the save progress mode or reset it every time you restart the game/save.

Thanks for the Kaoru test

*When used together with Ragdoll mod, almost all events can take place in a way that was not intended, so it is not recommended to use together with Ragdoll mod.

v1.1
- Added a new event "Help for alternative LL Cool J". Available after the Madd Dogg's Rhymes mission;
- Added a new event "Give a drunk a ride";
- Added a new event "Phone Order". We need to deliver a truck. Available after the Big Smoke mission;
- Added a new event "Phone Order". We need to steal a truck. Available after the Drive-By mission;
- Added subtitles;
- You can adjust the volume of sounds in the .ini file.;
- All sounds were compressed;
- The text in .the fxt file;
- Now you need to honk the horn to get into your car;
- Some events will only be available after a certain storyline progress;
- Fixed minor bugs;
- Some script/balance adjustments.

-----------------------------------------------------------------
Installation:
Move the "Random Events Project" folder to the "Modloader" folder. Ready!
-----------------------------------------------------------------
by ArtemQa146

https://www.gtainside.com/user/ArtemQa146
https://libertycity.ru/user/Artem.1.9.9.6/
https://youtube.com/@ArtemQa146