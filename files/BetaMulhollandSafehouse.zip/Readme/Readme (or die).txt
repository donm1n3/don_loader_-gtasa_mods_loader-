  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2022
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the folder "Beta Mulholland Safehouse" to your Modloader folder.
DESINSTALL OLD VERSION BEFORE INSTALLING THIS NEW ONE!
If your game was saved inside the house in the old version, you will have to delete the file in the "cleo/cleo_saves" folder (the number is the space of the saved game, with 0 being the first).

-- Essentials Pack download: https://www.mixmods.com.br/2019/06/sa-essentials-pack/
-- REQUIRES CLEO+ (already included in Essentials Pack).
-- REQUIRES Open Limit Adjuster: https://www.mixmods.com.br/2015/02/open-limit-adjuster/


 Attention: The mod almost does not replace the game files, but still replaces some ones.
��������� � You may need to increase the folder priority of this mod in modloader.ini:
            https://www.mixmods.com.br/2015/07/tutorial-dicas-tudo-sobre-modloader-gta/#Priority


 Local: In the house just at north of Madd Dogg's house.



Version: Unofficial Fix 8 + HD textures
--------------------

Author: Kalvin
Fixes and improvements: Robson Martins, Junior_Djjr
HD textures: RoSA Project Reborn, J�ssica Nat�lia, Junior_Djjr


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====

