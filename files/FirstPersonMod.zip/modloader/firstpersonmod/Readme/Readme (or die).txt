  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2025
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization in Notepad with monospaced font, as "Consolas".


------- Instructions:

Extract the files to your GTA SA folder (not compatible with ModLoader installation).
Unlike the old version, "msvcr100d.dll" is NOT required.

-- Essentials Pack download: https://www.mixmods.com.br/2019/06/sa-essentials-pack/



 = How to enable:
Change the camera (by default, V key) until you reach the first person camera.

 = Settings:
Press Alt+B to open settings menu to configure the camera's position of the skin or car, among other stuffs.

 = Problems:
Disable before the cutscene on the mission "OG Loc" or may crash.



Version: v3.0 FIXED + Fixed movement, added cars, Widescreen Fix, aim and FOV by Junior_Djjr + compatibility for new Widescreen Fix
--------------------

Author: BoPoH (Voron295)
Thanks to: DK22Pac, DenSpb
Some fixes: Crspy
FirstPersonModFix.asi: Junior_Djjr


====   MixMods.com.br         ====
====   fb.com/FamiliaMixMods  ====

