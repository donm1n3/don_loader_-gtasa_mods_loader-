---
EN-
---

Gasoline Mod

The mod adds fuel for cars and bikes. Despite the fact that there were many similar mods, I decided to make this mod using modern functions Cleo, also making more flexible settings for users, and in general the mod has a higher stability. You can replenish fuel at gas stations (the corresponding icon on the map) by driving up to any gas station. In the .ini file, you can specify how long 1 unit of fuel will be spent. Also, fuel consumption is affected by the gas pedal and the speed of the car, i.e. standing still and holding the gas pedal, the fuel will be spent a little faster, or vice versa, to save at high speed, you can release the gas pedal, which will slightly reduce fuel consumption. Visually, the mod looks quite neat, and there are also many different visual settings for users, position, size, color, etc.

v3.1
In missions, for balance, the car that the player gets into will have a fuel reserve of 75% to 100% (If On Mission = 1 is enabled in the .ini). Outside of missions, the fuel random remains the same, from 40% to 100%.

v3.0
- Added the option for the player to buy a canister of gasoline. Now, if your car has run out of fuel or you just want to fill a full tank of gasoline and there is no gas station nearby, you can use a gasoline canister. To buy a canister of gasoline, you need to go to the gas station and press the button. After buying a canister, when you get into a vehicle (car, motorcycle, boat), the gasoline canister icon will be displayed on the screen. To refuel, you need to hold down the Space + Y keys while in transport (you can change key id in .ini), wait 2 seconds and the player will start refueling your transport;
- If the fuel supply is low, the nearest refueling station will be displayed on the radar.

v2.9.1
- Fixed a bug with repeated scenes at gas stations, in the always-on cutscene mode (At gas stations in LV);
- Added the ability to skip the cutscene at the gas station after a few seconds (SPACE key);
- Reduced the price of fuel.

v2.9
- Fixed a bug where some indicators still displayed when hud is disabled (by rill_);
- Fixed a bug where player can refuel for free when setting "Mode" to vertical (by rill_);
- Added an option to disable indicator (by rill_);
- Fixed a potential game crash when using the GASRELOAD cheat;
- Added an icon for refueling in Valle Ocultado.

v2.8
- Reduced the cost of gasoline;
- Fixed a visual bug due to the same name of the gas pump model and game files;
- Fixed that Vertex belonged to the "aircraft" type and could only be refueled at the airport. Now it belongs to the "boat" class.

v2.7
Now motorcycles also have a scene at the gas station. It works the same as for cars, but CJ always refuels the bikes himself.

v2.6
- Added a classic interface style without an arrow. Vertical and horizontal modes are supported, as well as static or dynamic color (varies depending on the amount of fuel) The old interface with the arrow can be selected in the ini file;
- Added the ability to enable the mod in missions (disabled by default, enabled by .ini);
- Added refueling support from the new version of the "Proper Fixes" mod.

v2.5
- Now the gas station icons on the map for cars, air transport, water transport and interface have four different textures;
- Added the "Always on scene" mode for gas stations, Configured in the .ini file;
- The mod has been adapted to the mission (script) from Urbanize in Zone 69 and continues to work as before without shutting down;
- Fixed a minor bug where a script with icons was duplicated when a player boarded a water or air transport.

v2.4
- Added vertical mode (Included in .ini);
- Added the ability to disable icons on the map in .ini;
- Added the ability to disable icons in the interface in .ini;
- Added support for the Oil Leaking v3.0 mod from Junior_Djjr. When the engine is damaged and oil leaks begin, gasoline will start to be consumed faster (by ~10%). (Included in .ini).

v2.3
- The refueling icon on the radar and in the interface are now separate;
- The ability to turn on the static color of the strip;
- The ability to change the positions of fuel icons;

v2.2
- Added the ability in .ini to change the frequency of the scene at the gas station. There are 3 modes:
1. Completely disable the scene at the gas station;
2. Default, the scene at the gas station will appear when the icon starts flashing, i.e. fuel will be low (less than ~20%);
3. The scene will be very frequent, specifically when the fuel drops below 85%.
- Also in .ini, modes have been added for who will refuel the car:
1. Default, in cities - a gas station employee, in rural areas - CJ;
2. CJ only;
3. Only a gas station employee.
- Refueling stations for air transport have been redesigned. Now these are certain positions. When you get on a plane or helicopter, icons of the refueling place will appear on the map, and when approaching, an icon will hang over the desired place (Like for water transport);
- Another icon has been added to the map for refueling in the Temple/Mulholland (LS) area. If you do not have a gas station in this location, then you can install it from the "Temple Gas Station" folder;
- When entering a cheat code to replenish fuel, the cheat code will be taken into account in the game statistics and a notification will be added exactly the same as when entering regular cheat codes;
- Fixed when one of the gas stations in LV was not working if the Proper fix mod was installed;
- Added another refueling station for water transport in the north of LV;
- For those who use the SAxVCxLC mod, gas station icons have been added to Vice City and Liberty City (Included in .ini).

(Fix)
Fixed when fuel was not displayed on motorcycles.

v2.1
- Water transport now has fuel. Refueling points appear on the map when you get into the boat, and an icon will hang over the refueling place itself;
- If the car has an electric motor, the icon to the left of the scale will change to the battery icon. In addition, the scene with the gas station (employee or main character) will not work for electric vehicles;
- In the .ini file, you can turn on or off the class of transport for which gasoline will work or not, for example, if you do not need fuel on airplanes, then you can simply turn off;
- After changing the visual settings in .ini, it is not necessary to restart the game, you can enter the cheat code "GasReload", and the settings will restart. Convenient for fine-tuning to your interface!;
- Added a cheat code for a full tank - "GasolineQa".

v2.0
- If you stop at a gas station in an urban area, you can see how a gas station employee will fill up your car, and if you are in a rural area, the main character himself will fill up the car. This will work if you have a low fuel supply (when the tank icon flashes) and enough money to fill up a full tank, otherwise the usual refueling will take place;
- Now air transport also has fuel. You can refuel at airports or at helipads (You just need to stand still);
- When you run out of fuel, there will now be a sound signal along with the flashing icon. In the .ini file, you can adjust the volume of the sound;
- Added sound when refueling. In the .ini file, you can adjust the volume of the sound;
- If you save or drive the transport into the garage (after closing the door), then the transport will have a full tank.

Thanks for the ideas, tips and help: Artem_kostromi, Kumar, gund, Sergey, SergeDV, Romulo Monteiro, Crowdigger, _relaxxx_, eril24_, Dimoman.

-----------------------------------------------------------------
Installation:
Move the "Gasoline Mod" folder to the "Modloader" folder. Ready!
-----------------------------------------------------------------
by ArtemQa146

https://www.gtainside.com/user/ArtemQa146
https://libertycity.ru/user/Artem.1.9.9.6/
https://youtube.com/@ArtemQa146