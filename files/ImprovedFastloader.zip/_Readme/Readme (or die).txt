  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2018
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization in Notepad with monospaced font, as "Consolas".


------- Instructions:

Extract the files to any folder inside Modloader folder. Or if you prefer to your GTA SA directory.

 Optional: The "Max Settings - Max Settings" folder includes a maximum configuration, where you simply open the .exe that the game will open without any menu etc (from the second time).

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html


 DETAILS:
    The first time you open the game, you will be prompted to load a save game... The next time you open it will not ask for more. So if you want to change the save game, load another saved game while in game to change it.
    For you to disable save game auto load, you can hold CTRL when the game starts to open, so the load game/start game menu will appear.
    Read .ini for more options.
 

--------------------

Author: LINK/2012


====   MixMods.com.br         ====
====   fb.com/FamiliaMixMods  ====

